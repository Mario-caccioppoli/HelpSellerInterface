import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestione-ordini-campione',
  templateUrl: './gestione-ordini-campione.component.html',
  styleUrls: ['./gestione-ordini-campione.component.css']
})
export class GestioneOrdiniCampioneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
