import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visualizza-dettagli-prodotto',
  templateUrl: './visualizza-dettagli-prodotto.component.html',
  styleUrls: ['./visualizza-dettagli-prodotto.component.css']
})
export class VisualizzaDettagliProdottoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
