import { Divisione } from './divisione';

describe('Divisione', () => {
  it('should create an instance', () => {
    expect(new Divisione()).toBeTruthy();
  });
});
