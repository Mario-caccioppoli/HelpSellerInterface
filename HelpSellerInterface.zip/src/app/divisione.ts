export class Divisione {
        ID : number;
        via : string;
        civico : string;
        citta : string;
        provincia : string;
        cap : string;
        quantita : number;
        
        constructor(){}
        public setID(id:number){
            this.ID = id;
        
        }
        public setVia(via:string){
            this.via = via;
        
        }
        
        public setCivico(civico: string) {
            this.civico = civico;
        }
        public setCitta(citta: string) {
             this.citta = citta;
        }
        public setProvincia(provincia: string){
             this.provincia = provincia;
        }
        public setCAP(cap : string){
             this.cap = cap;
        }
        public setQuantita(quantita: number){
            this.quantita = quantita;
        }

        public getID() : number{
            return this.ID
        
        }

        public getVia() : string{
            return this.via
        
        }
        
        public getCivico() : string{
            return this.civico
        }
        public getCitta() : string{
            return this.citta
        }
        public getProvincia() : string{
            return this.provincia
        }
        public getCAP() : string{
            return this.cap
        }
        public getQuantita() : number{
            return this.quantita
        }
        public toString() : string{
            return this.via + " " +this.civico + " " +this.citta +" " +this.provincia +" " +this.cap +" "+this.quantita;
        }
        
        public toStringIndirizzo() : string{
            return this.via + " " +this.civico + " " +this.citta +" " +this.provincia +" " +this.cap ;
        }
}

