export interface Amministratore{
    id: number;
    username: string;
    email: string;
    password: string;
}