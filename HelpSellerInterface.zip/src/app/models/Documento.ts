export interface Documento{
    id: number;
    titolo: string;
    autore: string;
    data: Date;
    idOrdine: number;
}