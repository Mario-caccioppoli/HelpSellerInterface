
export interface Trasporto{
    id: number;
    indirizzoConsegna: string;
    quantitaMinima: number;
    dataConsegna: Date;
    idOrdine: number;
}