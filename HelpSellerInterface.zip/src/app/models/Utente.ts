export interface Utente{
    id: number;
    username: string;
    email: string;
    password: string;
    tipo: string;
    vat: string;
    indirizzo: string;
    descrizione: string;
    nome: string;
    cognome: string;
    telefono: number;
    logo: string;
}